<template>
  <div>
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">Blank Page</h1>
  </div>
</template>

<script>
export default {
    name: '404'
}
</script>