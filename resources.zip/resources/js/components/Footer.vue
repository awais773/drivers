<template>
    <footer class="footer footer-dark bg-dark">
      <div class="container text-center py-5">
        <p>
          Laravel and Vue Admin Dashboard @
        </p>
      </div>
    </footer>
</template>

<script>
export default {
    name: 'Footer'
}
</script>