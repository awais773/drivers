"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_views_admin_cards_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/admin/cards.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/admin/cards.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'Cards'
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!./node_modules/vue-loader/lib/loaders/templateLoader.js??ruleSet[1].rules[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/admin/cards.vue?vue&type=template&id=c97fd218&":
/*!************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!./node_modules/vue-loader/lib/loaders/templateLoader.js??ruleSet[1].rules[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/admin/cards.vue?vue&type=template&id=c97fd218& ***!
  \************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _vm._m(0);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("div", {
    staticClass: "d-sm-flex align-items-center justify-content-between mb-4"
  }, [_c("h1", {
    staticClass: "h3 mb-0 text-gray-800"
  }, [_vm._v("Cards")])]), _vm._v(" "), _c("div", {
    staticClass: "row"
  }, [_c("div", {
    staticClass: "col-xl-3 col-md-6 mb-4"
  }, [_c("div", {
    staticClass: "card border-left-primary shadow h-100 py-2"
  }, [_c("div", {
    staticClass: "card-body"
  }, [_c("div", {
    staticClass: "row no-gutters align-items-center"
  }, [_c("div", {
    staticClass: "col mr-2"
  }, [_c("div", {
    staticClass: "text-xs font-weight-bold text-primary text-uppercase mb-1"
  }, [_vm._v("\n                Earnings (Monthly)\n              ")]), _vm._v(" "), _c("div", {
    staticClass: "h5 mb-0 font-weight-bold text-gray-800"
  }, [_vm._v("\n                $40,000\n              ")])]), _vm._v(" "), _c("div", {
    staticClass: "col-auto"
  }, [_c("i", {
    staticClass: "fas fa-calendar fa-2x text-gray-300"
  })])])])])]), _vm._v(" "), _c("div", {
    staticClass: "col-xl-3 col-md-6 mb-4"
  }, [_c("div", {
    staticClass: "card border-left-success shadow h-100 py-2"
  }, [_c("div", {
    staticClass: "card-body"
  }, [_c("div", {
    staticClass: "row no-gutters align-items-center"
  }, [_c("div", {
    staticClass: "col mr-2"
  }, [_c("div", {
    staticClass: "text-xs font-weight-bold text-success text-uppercase mb-1"
  }, [_vm._v("\n                Earnings (Annual)\n              ")]), _vm._v(" "), _c("div", {
    staticClass: "h5 mb-0 font-weight-bold text-gray-800"
  }, [_vm._v("\n                $215,000\n              ")])]), _vm._v(" "), _c("div", {
    staticClass: "col-auto"
  }, [_c("i", {
    staticClass: "fas fa-dollar-sign fa-2x text-gray-300"
  })])])])])]), _vm._v(" "), _c("div", {
    staticClass: "col-xl-3 col-md-6 mb-4"
  }, [_c("div", {
    staticClass: "card border-left-info shadow h-100 py-2"
  }, [_c("div", {
    staticClass: "card-body"
  }, [_c("div", {
    staticClass: "row no-gutters align-items-center"
  }, [_c("div", {
    staticClass: "col mr-2"
  }, [_c("div", {
    staticClass: "text-xs font-weight-bold text-info text-uppercase mb-1"
  }, [_vm._v("\n                Tasks\n              ")]), _vm._v(" "), _c("div", {
    staticClass: "row no-gutters align-items-center"
  }, [_c("div", {
    staticClass: "col-auto"
  }, [_c("div", {
    staticClass: "h5 mb-0 mr-3 font-weight-bold text-gray-800"
  }, [_vm._v("\n                    50%\n                  ")])]), _vm._v(" "), _c("div", {
    staticClass: "col"
  }, [_c("div", {
    staticClass: "progress progress-sm mr-2"
  }, [_c("div", {
    staticClass: "progress-bar bg-info",
    staticStyle: {
      width: "50%"
    },
    attrs: {
      role: "progressbar",
      "aria-valuenow": "50",
      "aria-valuemin": "0",
      "aria-valuemax": "100"
    }
  })])])])]), _vm._v(" "), _c("div", {
    staticClass: "col-auto"
  }, [_c("i", {
    staticClass: "fas fa-clipboard-list fa-2x text-gray-300"
  })])])])])]), _vm._v(" "), _c("div", {
    staticClass: "col-xl-3 col-md-6 mb-4"
  }, [_c("div", {
    staticClass: "card border-left-warning shadow h-100 py-2"
  }, [_c("div", {
    staticClass: "card-body"
  }, [_c("div", {
    staticClass: "row no-gutters align-items-center"
  }, [_c("div", {
    staticClass: "col mr-2"
  }, [_c("div", {
    staticClass: "text-xs font-weight-bold text-warning text-uppercase mb-1"
  }, [_vm._v("\n                Pending Requests\n              ")]), _vm._v(" "), _c("div", {
    staticClass: "h5 mb-0 font-weight-bold text-gray-800"
  }, [_vm._v("18")])]), _vm._v(" "), _c("div", {
    staticClass: "col-auto"
  }, [_c("i", {
    staticClass: "fas fa-comments fa-2x text-gray-300"
  })])])])])])]), _vm._v(" "), _c("div", {
    staticClass: "row"
  }, [_c("div", {
    staticClass: "col-lg-6"
  }, [_c("div", {
    staticClass: "card mb-4"
  }, [_c("div", {
    staticClass: "card-header"
  }, [_vm._v("Default Card Example")]), _vm._v(" "), _c("div", {
    staticClass: "card-body"
  }, [_vm._v("\n          This card uses Bootstrap's default styling with no utility classes\n          added. Global styles are the only things modifying the look and feel\n          of this default card example.\n        ")])]), _vm._v(" "), _c("div", {
    staticClass: "card shadow mb-4"
  }, [_c("div", {
    staticClass: "card-header py-3"
  }, [_c("h6", {
    staticClass: "m-0 font-weight-bold text-primary"
  }, [_vm._v("\n            Basic Card Example\n          ")])]), _vm._v(" "), _c("div", {
    staticClass: "card-body"
  }, [_vm._v("\n          The styling for this basic card example is created by using default\n          Bootstrap utility classes. By using utility classes, the style of\n          the card component can be easily modified with no need for any\n          custom CSS!\n        ")])])]), _vm._v(" "), _c("div", {
    staticClass: "col-lg-6"
  }, [_c("div", {
    staticClass: "card shadow mb-4"
  }, [_c("div", {
    staticClass: "card-header py-3 d-flex flex-row align-items-center justify-content-between"
  }, [_c("h6", {
    staticClass: "m-0 font-weight-bold text-primary"
  }, [_vm._v("\n            Dropdown Card Example\n          ")]), _vm._v(" "), _c("div", {
    staticClass: "dropdown no-arrow"
  }, [_c("a", {
    staticClass: "dropdown-toggle",
    attrs: {
      href: "#",
      role: "button",
      id: "dropdownMenuLink",
      "data-toggle": "dropdown",
      "aria-haspopup": "true",
      "aria-expanded": "false"
    }
  }, [_c("i", {
    staticClass: "fas fa-ellipsis-v fa-sm fa-fw text-gray-400"
  })]), _vm._v(" "), _c("div", {
    staticClass: "dropdown-menu dropdown-menu-right shadow animated--fade-in",
    attrs: {
      "aria-labelledby": "dropdownMenuLink"
    }
  }, [_c("div", {
    staticClass: "dropdown-header"
  }, [_vm._v("Dropdown Header:")]), _vm._v(" "), _c("a", {
    staticClass: "dropdown-item",
    attrs: {
      href: "#"
    }
  }, [_vm._v("Action")]), _vm._v(" "), _c("a", {
    staticClass: "dropdown-item",
    attrs: {
      href: "#"
    }
  }, [_vm._v("Another action")]), _vm._v(" "), _c("div", {
    staticClass: "dropdown-divider"
  }), _vm._v(" "), _c("a", {
    staticClass: "dropdown-item",
    attrs: {
      href: "#"
    }
  }, [_vm._v("Something else here")])])])]), _vm._v(" "), _c("div", {
    staticClass: "card-body"
  }, [_vm._v("\n          Dropdown menus can be placed in the card header in order to extend\n          the functionality of a basic card. In this dropdown card example,\n          the Font Awesome vertical ellipsis icon in the card header can be\n          clicked on in order to toggle a dropdown menu.\n        ")])]), _vm._v(" "), _c("div", {
    staticClass: "card shadow mb-4"
  }, [_c("a", {
    staticClass: "d-block card-header py-3",
    attrs: {
      href: "#collapseCardExample",
      "data-toggle": "collapse",
      role: "button",
      "aria-expanded": "true",
      "aria-controls": "collapseCardExample"
    }
  }, [_c("h6", {
    staticClass: "m-0 font-weight-bold text-primary"
  }, [_vm._v("\n            Collapsable Card Example\n          ")])]), _vm._v(" "), _c("div", {
    staticClass: "collapse show",
    attrs: {
      id: "collapseCardExample"
    }
  }, [_c("div", {
    staticClass: "card-body"
  }, [_vm._v("\n            This is a collapsable card example using Bootstrap's built in\n            collapse functionality.\n            "), _c("strong", [_vm._v("Click on the card header")]), _vm._v(" to see the card body\n            collapse and expand!\n          ")])])])])])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./resources/js/views/admin/cards.vue":
/*!********************************************!*\
  !*** ./resources/js/views/admin/cards.vue ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _cards_vue_vue_type_template_id_c97fd218___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./cards.vue?vue&type=template&id=c97fd218& */ "./resources/js/views/admin/cards.vue?vue&type=template&id=c97fd218&");
/* harmony import */ var _cards_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./cards.vue?vue&type=script&lang=js& */ "./resources/js/views/admin/cards.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _cards_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _cards_vue_vue_type_template_id_c97fd218___WEBPACK_IMPORTED_MODULE_0__.render,
  _cards_vue_vue_type_template_id_c97fd218___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/views/admin/cards.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/views/admin/cards.vue?vue&type=script&lang=js&":
/*!*********************************************************************!*\
  !*** ./resources/js/views/admin/cards.vue?vue&type=script&lang=js& ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_cards_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./cards.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/admin/cards.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_cards_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/views/admin/cards.vue?vue&type=template&id=c97fd218&":
/*!***************************************************************************!*\
  !*** ./resources/js/views/admin/cards.vue?vue&type=template&id=c97fd218& ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_use_0_node_modules_vue_loader_lib_loaders_templateLoader_js_ruleSet_1_rules_2_node_modules_vue_loader_lib_index_js_vue_loader_options_cards_vue_vue_type_template_id_c97fd218___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_use_0_node_modules_vue_loader_lib_loaders_templateLoader_js_ruleSet_1_rules_2_node_modules_vue_loader_lib_index_js_vue_loader_options_cards_vue_vue_type_template_id_c97fd218___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_use_0_node_modules_vue_loader_lib_loaders_templateLoader_js_ruleSet_1_rules_2_node_modules_vue_loader_lib_index_js_vue_loader_options_cards_vue_vue_type_template_id_c97fd218___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ruleSet[1].rules[2]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./cards.vue?vue&type=template&id=c97fd218& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!./node_modules/vue-loader/lib/loaders/templateLoader.js??ruleSet[1].rules[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/admin/cards.vue?vue&type=template&id=c97fd218&");


/***/ })

}]);